package com.realestate.reatestate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReatestateApplicationTests {

	@Test
	void contextLoads() {
	}

}
